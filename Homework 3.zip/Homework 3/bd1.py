import datetime # добавяне на датата и времето

date_format = "%d.%m.%Y" # формат на задаване на датата ( ден,месец,година)
my_bd=input("Въведи рожденната си дата във формат 10.04.2000: ") # въвеждане на рождената дата
bd = datetime.datetime.strptime(my_bd, date_format) # връща стойността на bd в нашият date формат
today=datetime.datetime.today() # дава стойност на today като днешна дата
delta = today - bd # delta ни е равна на днешната минус рождената дата
de=delta.days # дава стойността dе като дните на delta
se=delta.seconds # дава стойността на de като секундите на delta

moon_months=round(de/28,2) # дава стойност на moon_months равна на закръглената стойност до два знака след запетаята
years=round(de/365,2) # дава стойност на years  равна на закръглената стойност до два знака след запетаята

my_time=[years,moon_months,de,se] # дава се стойност на my_time в същата последователност
print(my_time) # извежда се my_time
